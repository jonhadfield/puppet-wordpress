<?php
$search_term = substr($_SERVER['REQUEST_URI'],1);
$search_term = urldecode(stripslashes($search_term));
$find = array("'.html'", "'.+/'", "'[-/_]'");
$replace = " ";
$search_term = trim(preg_replace($find, $replace, $search_term));
$search_term_q = preg_replace('/ /', '%20', $search_term);
$redirect_location = get_home_url().'?s='.$search_term_q.'&search_404=1';
// header("Status: 404 Not Found"); 
// header($redirect_location);
get_header();
?>
<script type="text/javascript">
    jQuery(document).ready(function($){
		// $(location).attr('href', '<?php echo $redirect_location; ?>');
		window.location.replace("<?php echo $redirect_location; ?>");
    });
</script>

<h1 class="page-title">
    <?php
        printf(__('Searching for: <span>%s</span>', 'graphene'), $search_term);
    ?>
</h1>

<div class="post clearfix post_404">
    <div class="entry clearfix">
        <h2><?php _e('Error 404 - Page Not Found', 'graphene'); ?></h2>
        <div class="entry-content clearfix">
            <p><?php _e("Sorry, I've looked everywhere but I can't find the page you're looking for.", 'graphene'); ?></p>
            <p><?php _e("If you follow the link from another website, I may have removed or renamed the page some time ago. You may want to try searching for the page:", 'graphene'); ?></p>
            
            <?php get_search_form(); ?>
        </div>
    </div>
</div>
<div class="post clearfix post_404_search">
	<div class="entry clearfix"> 
	<h2><?php _e('Automated search', 'graphene'); ?></h2>   
        <div class="entry-content clearfix">
            <p>
            <?php printf(__('Searching for the terms <strong>%s</strong> ...', 'graphene'), $search_term); ?></p>
            </p>
        </div>
    </div>
</div>
<?php get_footer(); ?>
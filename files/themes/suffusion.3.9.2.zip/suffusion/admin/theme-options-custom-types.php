<?php
global $suffusion_custom_types_options;
$suffusion_custom_types_options = array(
	array("name" => "Custom Types",
		"type" => "sub-section-2",
		"category" => "custom-types",
		"parent" => "root"
	),
);
?>